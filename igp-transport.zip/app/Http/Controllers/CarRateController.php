<?php

namespace App\Http\Controllers;

use App\Models\CarRate;
use App\Http\Requests\StoreCarRateRequest;
use App\Http\Requests\UpdateCarRateRequest;

class CarRateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreCarRateRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCarRateRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CarRate  $carRate
     * @return \Illuminate\Http\Response
     */
    public function show(CarRate $carRate)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CarRate  $carRate
     * @return \Illuminate\Http\Response
     */
    public function edit(CarRate $carRate)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateCarRateRequest  $request
     * @param  \App\Models\CarRate  $carRate
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateCarRateRequest $request, CarRate $carRate)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CarRate  $carRate
     * @return \Illuminate\Http\Response
     */
    public function destroy(CarRate $carRate)
    {
        //
    }
}
